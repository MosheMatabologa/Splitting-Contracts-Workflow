
# num = eval(input('Please enter your number: '))
num = eval('123')
print(num + 1)       # 124

# num = int(input('Please enter your number: '))
num = int('123')
print(num + 1)       # 124

# num = input('Please enter your number: ')
num = '123'
print(int(num) + 1)  # 124

# num = input('Please enter your number: ')
# print(num + 1)     # TypeError: ...
