
from datetime import date
date_1 = date(1992, 1, 16)
date_2 = date(1991, 2, 5)
print(date_1 - date_2)  # 345 days, 0:00:00
print(type(date_1 - date_2))  # <class 'datetime.timedelta'>
