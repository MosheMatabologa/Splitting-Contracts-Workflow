
import math
print(math.sqrt(64))     # 8.0
print(math.hypot(3, 4))  # 5.0

import random
random.seed(0)

import platform
print(platform.processor())  # e.g. i386
