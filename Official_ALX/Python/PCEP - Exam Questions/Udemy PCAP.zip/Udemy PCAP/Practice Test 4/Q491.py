
class Example:
    def __str__(self):
        return __name__


thing = Example()
print(thing)  # __main__
