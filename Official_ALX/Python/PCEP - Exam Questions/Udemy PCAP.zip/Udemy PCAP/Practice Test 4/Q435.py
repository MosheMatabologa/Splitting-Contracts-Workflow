
print('Enter Your Name: ')
name = input()
print(name)
