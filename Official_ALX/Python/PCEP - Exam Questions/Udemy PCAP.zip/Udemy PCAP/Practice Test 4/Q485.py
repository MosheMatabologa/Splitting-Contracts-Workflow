
my_list = [1, 2, 3]
# print(my_list[7])  # IndexError: list index out of range

# print(int("Hello"))
# ValueError: invalid literal for int() with base 10: 'Hello'

int_value = 7
int_value += 1
print(int_value)  # 8

my_list2 = [1, 2, 3]
print(my_list2[100:200])  # []
