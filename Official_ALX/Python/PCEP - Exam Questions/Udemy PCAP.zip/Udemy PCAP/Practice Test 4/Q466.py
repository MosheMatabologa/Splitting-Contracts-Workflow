
print(ord('m'))  # 109
print(ord('M'))  # 77
