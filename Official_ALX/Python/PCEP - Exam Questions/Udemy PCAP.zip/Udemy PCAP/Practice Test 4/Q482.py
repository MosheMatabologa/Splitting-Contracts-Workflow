
s = lambda x: 0 if x == 0 else 1 if x > 0 else -1

print(s(-273.15))  # -1
