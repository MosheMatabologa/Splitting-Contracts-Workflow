
print(23 == 23)     # True

# print(23 === 23)  # SyntaxError: invalid syntax

w = 42

x = ['Peter']
y = ['Peter']
print(x is y)       # False
