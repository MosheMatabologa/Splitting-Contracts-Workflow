
print(chr(ord('p') + 3))  # s
print(ord('p'))           # 112
print(chr(115))           # s
