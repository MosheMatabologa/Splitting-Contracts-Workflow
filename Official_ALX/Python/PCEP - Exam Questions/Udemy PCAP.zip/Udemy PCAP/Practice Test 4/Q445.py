
from random import random
print(int(random() * 7))  # e.g. 4

print(random())           # e.g. 0.5653393171868492
print(random() * 7)       # e.g. 4.0610157611213675
print(int(random() * 7))  # e.g. 3
