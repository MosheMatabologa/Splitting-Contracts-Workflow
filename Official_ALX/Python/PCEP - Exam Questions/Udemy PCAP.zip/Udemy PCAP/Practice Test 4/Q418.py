
x = float('23.42')

print(bool(x) + True)  # 2
print(int(x) + False)  # 23
print(str(x))          # '23.42'
print(bool(x))         # True

print(float('23.42'))  # 23.42
print(bool(23.42))     # True

print(True + True)     # 2
print(True - False)    # 1
print(True * True)     # 1
print(True / True)     # 1.0
print(True % True)     # 0
