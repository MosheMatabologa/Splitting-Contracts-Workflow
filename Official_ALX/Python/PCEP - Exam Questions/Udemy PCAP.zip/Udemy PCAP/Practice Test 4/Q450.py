
try:
    print('try')      # try
    print(10 / 0)
except:
    print('except')   # except
else:
    print('else')
finally:
    print('finally')  # finally

# print(10 / 0)  # ZeroDivisionError: division by zero
