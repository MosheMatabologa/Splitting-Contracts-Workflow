
# assert 1 == 2  # AssertionError

st1 = {1, 2, 3}
st1.remove(5)    # KeyError: 5
