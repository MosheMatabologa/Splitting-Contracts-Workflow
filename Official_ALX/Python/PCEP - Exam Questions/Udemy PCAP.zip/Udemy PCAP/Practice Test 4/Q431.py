
data = 'Hello@Peter!!'
print(data.lower())  # hello@peter!!
