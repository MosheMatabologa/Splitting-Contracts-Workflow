
# a = eval(input('Enter a number for the equation: '))
a = eval('7')     # Just for convenience
print((-a) ** 2)  # 49
print(-(a) ** 2)  # -49
print(-a ** 2)    # -49
print(-(a ** 2))  # -49
