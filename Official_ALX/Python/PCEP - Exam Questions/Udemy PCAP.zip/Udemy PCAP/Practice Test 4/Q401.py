
def a(b, c, d):
    pass
