
class Dog:
    def __init__(self, name):
        self.name = name


dog1 = Dog('Boomer')
dog2 = Dog('Lassie')
print(dog1.name, dog2.name)  # Boomer Lassie
