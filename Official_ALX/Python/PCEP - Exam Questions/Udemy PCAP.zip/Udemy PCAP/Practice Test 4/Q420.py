
num = 42

# Code-1
if num % 2 == 0:
    even = True
else:
    even = False

# Code-2
even = True if num % 2 == 0 else False

# Code-3
even = num % 2 == 0
