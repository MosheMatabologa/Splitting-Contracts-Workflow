
print('Hello' + ' ' + 'world')  # Hello world
print('Hello' * 3)              # HelloHelloHello
print('e' in 'Hello' * 3)       # True
# print('Hello' - 'Hell')       # TypeError: ...
