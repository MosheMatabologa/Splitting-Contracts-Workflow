
a = 1
b = 0
c = a & b
d = a | b
e = a ^ b
print(c + d + e)  # 2

print(1 & 0)      # 0
print(1 | 0)      # 1
print(1 ^ 0)      # 1
