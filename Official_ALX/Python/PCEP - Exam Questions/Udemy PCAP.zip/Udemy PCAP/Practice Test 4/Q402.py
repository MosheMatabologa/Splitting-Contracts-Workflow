
# def 1function(): pass  # SyntaxError: invalid syntax
def _function1():
    pass


def Function1():
    pass


def Function_1():
    pass


def Func_1_tion():
    pass
