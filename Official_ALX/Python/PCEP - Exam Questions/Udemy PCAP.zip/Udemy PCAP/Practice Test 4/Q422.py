
def func1(x):
    return str(x)


def func2(x):
    return str(2 * x)


print(func1(1) + func2(2))  # 14
