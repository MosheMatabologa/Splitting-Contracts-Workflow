
import math

x = -1.5
print(abs(math.floor(x) + math.ceil(x)))        # 3
print(abs(math.floor(-1.5) + math.ceil(-1.5)))  # 3
print(math.floor(-1.5))  # -2
print(math.ceil(-1.5))   # -1
print(abs(-2 + -1))                             # 3
print(-2 + -1)           # -3
print(abs(-3))                                  # 3
