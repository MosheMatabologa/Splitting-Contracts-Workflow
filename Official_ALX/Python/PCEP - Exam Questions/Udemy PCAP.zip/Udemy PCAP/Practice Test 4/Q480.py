
l = [x for x in range(1, 10, 3) if x % 2 == 0]
print(len(l))  # 1
print(l)  # [4]
print(list(range(1, 10, 3)))  # [1, 4, 7]
