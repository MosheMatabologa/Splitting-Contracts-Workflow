
print(type(+1E10))   # <class 'float'>
print(type(5.0))     # <class 'float'>
print(type('True'))  # <class 'str'>
print(type(False))   # <class 'bool'>
