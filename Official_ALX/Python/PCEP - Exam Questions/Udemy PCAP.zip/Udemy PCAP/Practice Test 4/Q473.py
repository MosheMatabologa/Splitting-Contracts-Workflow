
from math import hypot
parendicular = 3
base = 4
print(hypot(parendicular, base))  # 5.0


import math
parendicular = 3
base = 4
print(math.hypot(parendicular, base))  # 5.0
