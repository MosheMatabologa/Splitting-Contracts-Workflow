
class Test:
    def __init__(self):
        pass


obj = Test()
# obj = Test(1)     # TypeError: ...
# obj = Test(1, 2)  # TypeError: ...
# obj = Test('1')   # TypeError: ...
