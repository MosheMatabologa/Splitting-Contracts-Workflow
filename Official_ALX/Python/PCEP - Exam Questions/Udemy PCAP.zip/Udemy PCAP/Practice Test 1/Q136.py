
# x = input()
# y = input()
x, y = '2', '4'  # Just for convenience
print(x + y)     # 24
