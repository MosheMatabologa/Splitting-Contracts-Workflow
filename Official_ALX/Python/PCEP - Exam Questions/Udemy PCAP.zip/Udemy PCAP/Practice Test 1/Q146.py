
nums = [3, 4, 5, 20, 5, 25, 1, 3]
nums.pop(1)
print(nums)  # [3, 5, 20, 5, 25, 1, 3]
