
def test(x=1, y=2):
    x = x + y    # 2 + 1 -> 3
    y += 1       # 1 + 1 -> 2
    print(x, y)  # 3 2


test(2, 1)  # 3 2
