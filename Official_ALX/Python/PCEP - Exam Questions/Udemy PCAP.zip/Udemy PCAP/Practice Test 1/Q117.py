
print(list('hello'))  # ['h', 'e', 'l', 'l', 'o']
