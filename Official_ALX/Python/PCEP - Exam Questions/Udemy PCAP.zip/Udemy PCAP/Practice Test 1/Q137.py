
z = y = x = 1
print(x, y, z, sep='*')  # 1*1*1
print(x, y, z, sep=' ')  # 1 1 1
print(x, y, z)           # 1 1 1
