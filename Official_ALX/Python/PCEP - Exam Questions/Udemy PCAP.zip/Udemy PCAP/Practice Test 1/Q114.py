
for i in range(1, 6):
    print(str(i) * 5)
"""
11111
22222
33333
44444
55555
"""

print('----------')

for i in range(0, 5):
    print(str(i) * 5)
"""
00000
11111
22222
33333
44444
"""

print('----------')

for i in range(1, 6):
    print(i, i, i, i, i)
"""
1 1 1 1 1
2 2 2 2 2
3 3 3 3 3
4 4 4 4 4
5 5 5 5 5
"""

print('----------')

for i in range(1, 5):
    print(str(i) * 5)
"""
11111
22222
33333
44444
"""
