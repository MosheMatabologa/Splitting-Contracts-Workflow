
x = True
y = False
z = False

# if not x or y:
# if (not True) or False:
# if False or False:
if False:
    print(1)
# elif not x or not y and z:
# elif (not True) or (not False) and False:
# elif False or True and False:
# elif False or (True and False):
# elif False or False:
elif False:
    print(2)
# elif not x or y or not y and x:
# elif (not True) or False or (not False) and True:
# elif False or False or True and True:
# elif False or False or (True and True):
# elif False or False or True:
# elif (False or False) or True:
# elif False or True:
elif True:
    print(3)  # 3
else:
    print(4)
