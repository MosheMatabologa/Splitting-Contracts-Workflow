
class A:
    def __init__(self, name):
        self.name = name

    # def __str__(self):
        # return "I am an object, goo goo g'joob!"


a = A('class')
print(a)  # e.g. <__main__.A object at 0x7f89def876d0>
