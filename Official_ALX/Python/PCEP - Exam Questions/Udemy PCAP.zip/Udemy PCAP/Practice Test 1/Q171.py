
try:
    # number = input('Please enter a number\n')
    number = 'seven'
    zahl = int(number)
    result = zahl * zahl
    print(result)
except:
    print('Something went wrong.')
