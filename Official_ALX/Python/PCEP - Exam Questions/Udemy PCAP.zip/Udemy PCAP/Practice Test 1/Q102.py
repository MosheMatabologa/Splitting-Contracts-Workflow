
x = 2
y = 1
# x *= y + 1
x = x * (y + 1)
print(x)  # 4
