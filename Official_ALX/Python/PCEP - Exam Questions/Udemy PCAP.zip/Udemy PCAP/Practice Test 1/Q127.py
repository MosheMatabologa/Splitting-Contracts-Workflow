
def func():
    try:
        print(23)  # 23
    finally:
        print(42)  # 42


func()
