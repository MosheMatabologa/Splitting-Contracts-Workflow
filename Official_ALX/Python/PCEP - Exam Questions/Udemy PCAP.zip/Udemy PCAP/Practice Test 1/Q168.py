
x = lambda a, b: a ** b
print(x(2, 10))  # 1024


def y(a, b):
    return a ** b


print(y(2, 10))  # 1024

# PEP8: E731 Do not assign a lambda expression, use a def
