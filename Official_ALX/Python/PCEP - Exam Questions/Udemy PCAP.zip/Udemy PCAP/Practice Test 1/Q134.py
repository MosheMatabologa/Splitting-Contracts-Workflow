
print(30.11E9)        # 30110000000.0
# print(30E11.9)      # SyntaxError: invalid syntax
# print(30.11E9.0)    # SyntaxError: invalid syntax
# print(30.11*10^9)   # TypeError: unsupported operand ...

print(30.11 * 10 ** 9)  # 30110000000.0
