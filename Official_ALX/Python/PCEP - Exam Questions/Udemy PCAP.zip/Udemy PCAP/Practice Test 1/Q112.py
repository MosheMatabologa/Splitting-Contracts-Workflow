
x = 4
if x % 2 == 0:
    print('x is an even number')  # x is an even number
