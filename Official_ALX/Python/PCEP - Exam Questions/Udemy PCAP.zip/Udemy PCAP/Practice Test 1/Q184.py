
file = open('data.txt', 'w')

file.close()

# Cleanup code (to remove the file again):
# import os
# os.remove("data.txt")
