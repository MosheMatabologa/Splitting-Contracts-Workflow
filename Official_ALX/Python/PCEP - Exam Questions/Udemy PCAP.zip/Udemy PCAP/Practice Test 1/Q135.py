
print(0o10)  # 8
print(0o77)  # 63
