
def func1():
    pass


print(func1())  # None


def func2():
    return


print(func2())  # None
