
import math

result = math.e != math.pow(2, 4)
print(int(result))

print(math.e)  # 2.718281828459045
print(math.pow(2, 4))  # 16.0
print(pow(2, 4))  # 16
