
print("King's Cross Station")  # King's Cross Station
print("""The Knights Who Say 'Ni!'""")  # The Knights Who Say 'Ni!'
# print("\")  # SyntaxError: EOL while scanning string literal
# print('All the king's horses')  # SyntaxError: invalid syntax
