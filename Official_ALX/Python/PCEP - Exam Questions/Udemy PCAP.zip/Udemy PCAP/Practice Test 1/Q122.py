
i = 0
while i <= 3:   # i=0, i=2
    i += 2
    print('*')
"""
*
*
"""
