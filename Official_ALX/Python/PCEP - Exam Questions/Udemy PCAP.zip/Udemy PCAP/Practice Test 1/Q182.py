
print((lambda x, y: x + y)(7, 11))  # 18

print((lambda x, y: '0123456789'[x:y])(3, 7))  # 3456

# print((lambda x,y -> x ** y)(7, 11))
# SyntaxError: invalid syntax

# print((lambda f(x,y): return x >> y)(7, 11))
# SyntaxError: invalid syntax
