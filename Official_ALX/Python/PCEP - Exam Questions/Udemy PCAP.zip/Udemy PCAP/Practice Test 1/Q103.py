
x = 1
y = 2
z = x
print(z)     # 1
x = y
print(x)     # 2
y = z
print(y)     # 1
print(x, y)  # 2 1
