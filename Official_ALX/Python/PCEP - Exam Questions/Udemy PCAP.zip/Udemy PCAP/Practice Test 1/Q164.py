
try:
    # number = input('Please enter a number\n')
    number = 'one'
    zahl = int(number)
    print('Perfekt!')
except:
    print('Something went wrong.')

# zahl = int('one')  # ValueError: invalid literal for int() with base 10: 'one'
