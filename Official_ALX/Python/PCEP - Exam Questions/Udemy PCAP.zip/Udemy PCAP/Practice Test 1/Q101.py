
print(3 / 5)  # 0.6
print(4 / 2)  # 2.0
