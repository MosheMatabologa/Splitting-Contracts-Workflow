
def func(text, num):
    while num > 0:
        print(text)
        num = num - 1


func('Hello', 3)
"""
Hello
Hello
Hello
"""
