
x = 1


def a(x):
    return 2 * x


x = 2 + a(x)      # Line 8
print(a(x))       # Line 9
# 8
