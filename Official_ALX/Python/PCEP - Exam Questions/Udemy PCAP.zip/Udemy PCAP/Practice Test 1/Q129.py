
class Test:
    def __init__(self, s='Welcome'):
        self.s = s

    def print(self):
        print(self.s)


x = Test()
x.print()  # Welcome
