
import platform
print(platform.system())     # e.g. Darwin or Windows
print(platform.version())    # e.g. Darwin Kernel Version 20.5.0 ... or 10.0.21390
print(platform.processor())  # e.g. i386 or ARMv8 (64-bit)
