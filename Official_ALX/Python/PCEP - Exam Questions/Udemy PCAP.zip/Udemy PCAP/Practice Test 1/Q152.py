
print(len('\''))  # 1
