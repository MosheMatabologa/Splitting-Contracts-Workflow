
L = [i for i in range(-1, -2)]
print(L)       # []
print(len(L))  # 0
