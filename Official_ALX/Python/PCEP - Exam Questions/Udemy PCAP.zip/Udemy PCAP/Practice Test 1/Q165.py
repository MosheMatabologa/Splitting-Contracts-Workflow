
print('James007'.isalnum())     # True
print('Hello world'.isalnum())  # False
