
import os
os.makedirs("a/b/c/d")
os.mkdir("a/b/c/d")  # FileExistsError: ...
