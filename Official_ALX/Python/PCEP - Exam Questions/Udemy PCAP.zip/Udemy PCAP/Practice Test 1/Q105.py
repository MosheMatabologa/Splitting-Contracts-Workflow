
data = ['Paul', 404, 3.03, 'Wellert', 33.3]
print(data[1:3])  # [404, 3.03]
