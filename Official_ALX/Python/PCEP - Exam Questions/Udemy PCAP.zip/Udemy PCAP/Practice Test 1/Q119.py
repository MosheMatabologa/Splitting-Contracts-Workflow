
z = 3
y = 7
x = y < z and z > y or y > z and z < y
print(x)                                     # True

print(y < z and z > y or y > z and z < y)    # True
print(7 < 3 and 3 > 7 or 7 > 3 and 3 < 7)    # True
print(False and False or True and True)      # True
print((False and False) or (True and True))  # True
print(False or True)                         # True
print(True)                                  # True
