
foo = [i + i for i in range(5)]
print(foo)  # [0, 2, 4, 6, 8]

print(list(range(5)))         # [0, 1, 2, 3, 4]
print([i for i in range(5)])  # [0, 1, 2, 3, 4]
