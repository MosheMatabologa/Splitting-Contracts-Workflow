
print('AXBYCZ'[::2])   # ABC
print('ABCDEF'[:3])    # ABC
print('AXBYCZ'[::-2])  # ZYX
print('FEDCBA'[-3:])   # CBA
