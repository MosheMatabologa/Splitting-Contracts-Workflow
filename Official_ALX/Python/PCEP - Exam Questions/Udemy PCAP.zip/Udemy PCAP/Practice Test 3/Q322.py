
data = ()
print(data.__len__())  # 0
print(len(data))       # 0

print(type(data))      # <class 'tuple'>
