
# value = input("Enter a value: ")
value = "0"
print(10/value)
# TypeError: unsupported operand type(s) for /: 'int' and 'str'
