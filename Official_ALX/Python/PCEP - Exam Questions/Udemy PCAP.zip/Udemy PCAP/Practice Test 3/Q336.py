
print(ord('c') - ord('a'))  # 2
print(ord('c'))             # 99
print(ord('a'))             # 97
