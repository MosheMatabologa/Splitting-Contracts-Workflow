
print(type(1 / 2))  # <type 'float'>
print(1 / 2)        # 0.5
print(1 / 1)        # 1.0
