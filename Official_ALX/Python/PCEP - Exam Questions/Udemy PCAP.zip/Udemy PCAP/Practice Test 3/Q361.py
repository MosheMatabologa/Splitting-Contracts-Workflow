
from random import randint

for i in range(2):
    print(randint(1, 2), end='')  # 11, 12, 21, or 22
