
strng = "Hello"
print(strng.rfind("Hell"))  # 0
print(strng.index("Hell"))  # 0

print(find("Hello", "Hell"))
# NameError: name 'find' is not defined
