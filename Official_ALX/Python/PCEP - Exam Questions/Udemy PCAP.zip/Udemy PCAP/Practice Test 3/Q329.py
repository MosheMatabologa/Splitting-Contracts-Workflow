
# x = float(input())
# y = float(input())
x, y = float('2'), float('4')  # Just for convenience
print(y ** (1 / x))    # 2.0
print(4.0 ** (1 / 2))  # 2.0
print(4.0 ** 0.5)      # 2.0
import math
print(math.sqrt(4))    # 2.0
