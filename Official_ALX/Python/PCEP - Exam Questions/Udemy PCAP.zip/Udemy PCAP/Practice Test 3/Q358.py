
# Example of a whole line as a comment
print('Hello')  # Example of the rest of a line as a comment
