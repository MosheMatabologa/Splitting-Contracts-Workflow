
def func(item):
    item += [1]   # [1, 2, 3, 4] + [1] -> [1, 2, 3, 4, 1]


data = [1, 2, 3, 4]
func(data)
print(len(data))  # 5

print(data)       # [1, 2, 3, 4, 1]
x = [1, 2, 3, 4]
x.append([1])
print(x)          # [1, 2, 3, 4, [1]]
