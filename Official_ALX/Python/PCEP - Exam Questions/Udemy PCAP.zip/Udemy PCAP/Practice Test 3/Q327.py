
data = (1, 2, 4, 8)
data = data[1:-1]
print(data)          # (2, 4)
data = data[0]
print(data)          # 2
