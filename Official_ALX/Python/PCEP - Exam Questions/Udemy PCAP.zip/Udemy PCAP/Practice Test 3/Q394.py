
class Dog:
    def __str__(self ):
        return "I am a dog!"


dog = Dog()
print(dog)  # I am a dog!
