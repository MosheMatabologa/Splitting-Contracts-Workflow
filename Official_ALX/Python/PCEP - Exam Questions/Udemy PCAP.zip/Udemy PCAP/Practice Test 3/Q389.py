
from tkinter import messagebox

messagebox.showinfo("Hello")
