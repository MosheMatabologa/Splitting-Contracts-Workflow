
def func(x):
    global y
    y = x * x
    return y


func(2)
print(y)  # 4
