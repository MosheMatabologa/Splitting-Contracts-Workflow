
x = []
x.append(1)
x.append(2)
x.append(3)
print(x.pop())  # 3
print(x.pop())  # 2
print(x.pop())  # 1
