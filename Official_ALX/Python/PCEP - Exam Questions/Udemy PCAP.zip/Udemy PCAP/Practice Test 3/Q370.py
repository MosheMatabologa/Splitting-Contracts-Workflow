
import calendar

c = calendar.Calendar()
# c = calendar.Calendar(firstweekday=1)

for weekday in c.iterweekdays():
    print(weekday, end=" ")  # 0 1 2 3 4 5 6
