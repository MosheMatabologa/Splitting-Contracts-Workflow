
x = lambda a: a + 10
print(x(5))  # 15
