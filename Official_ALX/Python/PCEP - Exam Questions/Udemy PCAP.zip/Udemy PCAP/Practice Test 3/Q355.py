
num = 2 + 3 * 5
print(Num)  # NameError: name 'Num' is not defined
# print(num)
