
data = (1,) * 3
data[0] = 2  # TypeError: ...
print(data)
