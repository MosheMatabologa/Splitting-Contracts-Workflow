
def test(x=1, y=2):
    x = x + y    # 1 + 2 -> 3
    y += 1       # 2 + 1 -> 3
    print(x, y)  # 3 3


test()
