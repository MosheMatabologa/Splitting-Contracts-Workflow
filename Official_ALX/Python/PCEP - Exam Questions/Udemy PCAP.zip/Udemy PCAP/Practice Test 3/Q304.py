
data = [i for i in range(-1, 2)]

print(data)                # [-1, 0, 1]
print(len(data))           # 3

print(list(range(-1, 2)))  # [-1, 0, 1]
