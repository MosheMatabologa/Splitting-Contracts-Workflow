
print(type(1J))      # <class 'complex'>

c = 1j
print(c.real)        # 0.0
print(c.imag)        # 1.0
print(type(0 + 1j))  # <class 'complex'>
