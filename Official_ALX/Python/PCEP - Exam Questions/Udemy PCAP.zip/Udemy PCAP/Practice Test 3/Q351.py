
def func():
    try:
        print('Monday')  # Monday
    finally:
        print('Friday')  # Friday


func()
