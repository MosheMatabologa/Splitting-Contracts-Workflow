
print(ord('x') - ord('X') == ord(' '))  # True
print(chr(ord('k') + 2) == 'm')         # True
print(chr(ord('k') + 2) == 'i')         # False
print(ord('x') + ord('X') == ord(' '))  # False
