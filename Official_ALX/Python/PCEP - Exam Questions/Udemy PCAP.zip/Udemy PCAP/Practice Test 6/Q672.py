
import os
os.mkdir('pictures')
os.chdir('pictures')
print(os.getcwd())  # .../pictures
