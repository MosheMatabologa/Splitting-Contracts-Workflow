
print(' ' * 0 < 1 * ' ')    # True
# An empty string is the least possible string and lesser than ' '.

print('Analog' < 'analog')  # True
# Upper-case letters are less than theri lower-case counterparts.

print(str(None) == None)    # False
# str(None) becomes the string "None" is is not the None value.

print(str(None) != 'None')  # False
# str(None) becomes the string "None" and is not not equal to it.
