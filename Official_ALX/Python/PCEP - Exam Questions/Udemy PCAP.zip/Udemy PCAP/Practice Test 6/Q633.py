
a = 28
b = 8
print(a / b)   # 3.5
print(a // b)  # 3
print(a % b)   # 4
