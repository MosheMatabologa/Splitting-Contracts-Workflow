
data = (1, 2, 3, 4)
data = data[-2:-1]
print(data)  # (3,)
data = data[-1]
print(data)  # 3
