
def func(x):
    if x == 0:
        return 0
    return x + func(x - 1)  # 3 + 2 + 1 + 0


print(func(3))  # 6
