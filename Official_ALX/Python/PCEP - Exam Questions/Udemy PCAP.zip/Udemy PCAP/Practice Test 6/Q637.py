
print(type(1876.23))  # <class 'float'>
print(type(+42E7))    # <class 'float'>
print(type('Italy'))  # <class 'str'>

print(10e6)  # 10000000.0
