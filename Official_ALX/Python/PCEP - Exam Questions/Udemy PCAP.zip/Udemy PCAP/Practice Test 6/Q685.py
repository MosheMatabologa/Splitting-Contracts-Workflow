
try:
    print(7 / 0)
    # I am a syntax error
except:
    print("You cannot divide by zero!")
