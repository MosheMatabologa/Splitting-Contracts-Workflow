
def function(x=0):
    return x


print(function())        # 0
print(function(7))       # 7
# print(function(4, 7))  # TypeError: ...
