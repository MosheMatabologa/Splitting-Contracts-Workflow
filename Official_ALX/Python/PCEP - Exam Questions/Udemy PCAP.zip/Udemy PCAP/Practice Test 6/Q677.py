
int_value = 7
int_value -= 1
print(int_value)  # 6

my_list2 = [1, 2, 3]
print(my_list2[100:200])  # []

my_tuple = (1, 2, 3)
# print(my_tuple[7])  # IndexError: tuple index out of range

print(float("Hello"))
# ValueError: could not convert string to float: 'Hello'
