
data = ['Peter', 'Paul', 'Mary']
print(data[int(-1 / 2)])  # Peter

print(-1 / 2)     # -0.5
print(int(-0.5))  # 0
