
import time
time.sleep(3)
print("Wake up!")
