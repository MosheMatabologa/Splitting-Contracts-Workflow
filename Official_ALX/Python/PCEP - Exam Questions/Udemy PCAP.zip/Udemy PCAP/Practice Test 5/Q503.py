
data = ((1, 2),) * 7
print(len(data[3:8]))    # 4

print(data)
# ((1, 2), (1, 2), (1, 2), (1, 2), (1, 2), (1, 2), (1, 2))
print(len(data[3:100]))  # 4
