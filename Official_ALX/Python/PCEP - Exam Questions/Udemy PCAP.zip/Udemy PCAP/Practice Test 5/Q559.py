
# First execute the following to create the needed file:
with open('test.py', 'w') as f:
    f.write('print(__name__)')

print(__name__)  # __main__
import test  # test
