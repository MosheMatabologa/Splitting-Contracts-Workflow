
from datetime import timedelta

delta = timedelta(weeks=1, days=7, hours=11)
print(delta * 2)  # 28 days, 22:00:00
