
data = {'Peter': 30, 'Paul': 31}
print(list(data.keys()))  # ['Peter', 'Paul']
print(data.keys())        # dict_keys(['Peter', 'Paul'])
