
def func(x):
    if x % 2 == 0:
        return 1
    else:
        return


print(func(func(2)) + 1)  # TypeError: ...
