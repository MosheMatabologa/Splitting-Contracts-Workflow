
import random
print([random.randint(1, 7) for i in range(1, 8)])
# e.g. [6, 3, 7, 5, 1, 4, 2]
print([random.randint(1, 8) for i in range(1, 8)])
# e.g. [6, 7, 3, 1, 8, 7, 8]
print(random.randrange(1, 7))  # e.g. 6
print(random.randint(1, 7))    # e.g. 7
