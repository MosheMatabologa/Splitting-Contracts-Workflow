
def func(x, y):
    if x == y:
        return x
    else:
        return


# func(x, y=1)  # NameError: name 'x' is not defined
print(func(0, 3))
