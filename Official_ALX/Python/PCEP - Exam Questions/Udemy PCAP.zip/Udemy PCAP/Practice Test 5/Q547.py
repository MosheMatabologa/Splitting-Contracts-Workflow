
import random
print(random.seed(3))  # None
