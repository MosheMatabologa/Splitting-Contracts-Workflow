
# The calc_power function calculates exponents
# x is the base
# y is the exponent
# The value of x raised to the y power is returned
def calc_power(x, y):
    comment = "# Return the value"
    # print(comment)  # '# Return the value'
    return x ** y   # raise x to the y power


print(calc_power(2, 8))  # 256
