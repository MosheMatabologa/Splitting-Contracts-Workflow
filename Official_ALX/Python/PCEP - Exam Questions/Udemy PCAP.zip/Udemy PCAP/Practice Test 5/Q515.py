
x = 'Peter'
y = 'Peter'
res = x is y       # True
print(res)

print(x < y)       # False
print(x != y)      # False
print(x is not y)  # False

print(id(x))  # e.g. 140539652049216
print(id(y))  # e.g. 140539652049216 (the same number)
