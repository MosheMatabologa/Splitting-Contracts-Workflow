
strng = '\''.join(("Mary", "had", "21", "sheep"))
print(strng)                 # Mary'had'21'sheep
print(strng[0:1])            # M
print(strng[0:1].islower())  # False
