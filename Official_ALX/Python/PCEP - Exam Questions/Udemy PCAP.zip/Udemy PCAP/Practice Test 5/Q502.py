
data1 = '1', '2'
data2 = ('3', '4')
print(data1 + data2)  # ('1', '2', '3', '4')
