
for i in range(1):
    print('i:', 1)  # 1
    print('*')      # *
else:
    print('*')      # *
