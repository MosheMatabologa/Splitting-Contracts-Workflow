
import calendar
cal = calendar.isleap(2019)
print(cal)  # False
