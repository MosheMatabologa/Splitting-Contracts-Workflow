
data = [1, 2, 3, None, (), [], ]
print(len(data))  # 6
