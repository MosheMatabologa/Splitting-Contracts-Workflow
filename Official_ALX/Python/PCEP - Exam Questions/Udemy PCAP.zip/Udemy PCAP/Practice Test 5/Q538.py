
print(type('Peter'))  # <class 'str'>
print(type(23))       # <class 'int'>
print(type(True))     # <class 'bool'>
