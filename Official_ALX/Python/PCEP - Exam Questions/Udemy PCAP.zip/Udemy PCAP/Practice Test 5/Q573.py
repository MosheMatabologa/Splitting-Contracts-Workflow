
class Class:
    def __init__(self, val=0):
        pass


# object = Class(1, 2)  # TypeError ...
object = Class()
object = Class(1)
object = Class(None)
