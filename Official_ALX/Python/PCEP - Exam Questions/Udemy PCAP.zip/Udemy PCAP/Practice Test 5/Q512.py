
print(3 * 'abc' + 'xyz')    # abcabcabcxyz
print((3 * 'abc') + 'xyz')  # abcabcabcxyz
print('abcabcabc' + 'xyz')  # abcabcabcxyz
print('abcabcabcxyz')       # abcabcabcxyz
