
x = 1
print(++++x)  # 1

print(+1)     # 1
print(++1)    # 1
print(+++1)   # 1
print(++++1)  # 1

print(-1)     # -1
print(--1)    # 1
print(---1)   # -1
print(----1)  # 1
