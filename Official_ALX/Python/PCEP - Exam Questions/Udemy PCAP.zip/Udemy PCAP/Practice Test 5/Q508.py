
data = (1, 2, 4, 8)
data = data[-2:-1]
print(data)  # (4,)
data = data[-1]
print(data)  # 4
