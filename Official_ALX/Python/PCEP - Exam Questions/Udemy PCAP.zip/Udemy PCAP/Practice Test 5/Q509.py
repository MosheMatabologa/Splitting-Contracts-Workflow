
# x = int(input())  # Input: 2
# y = int(input())  # Input: 4
x, y = int('2'), int('4')   # Just for convenience
print(x + y)                # 6

print(int('2') + int('4'))  # 6
print(2 + 4)                # 6
