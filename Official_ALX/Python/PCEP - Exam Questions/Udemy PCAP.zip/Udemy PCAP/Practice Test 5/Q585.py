
# print(Hello, World!)
# SyntaxError: invalid syntax
