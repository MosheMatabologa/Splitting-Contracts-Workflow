
nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
x = 0
while x < 10:         # Line 3
    print(nums[x])    # Line 4
    if nums[x] == 7:  # Line 5
        break         # Line 6
    else:             # Line 7
        x += 1        # Line 8
