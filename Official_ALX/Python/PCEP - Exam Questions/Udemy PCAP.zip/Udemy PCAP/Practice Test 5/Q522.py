
def func(x=2, y=3):
    return x * y


print(func(y=2))  # 4
