
print(type(23 + 42))      # <class 'int'>
print(type('23' + '42'))  # <class 'str'>
print(type('23' * 7))     # <class 'str'>
print(23 + 42)            # 65
print('23' + '42')        # 2342
print('23' * 7)           # 23232323232323
