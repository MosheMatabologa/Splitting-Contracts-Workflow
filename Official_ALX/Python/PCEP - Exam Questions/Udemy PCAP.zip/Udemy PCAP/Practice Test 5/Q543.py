
x, y, z = 3, 2, 1
z, y, x = x, y, z  # z, y, x = 3, 2, 1
print(x, y, z)     # 1, 2, 3
