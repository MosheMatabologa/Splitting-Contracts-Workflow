
print(1)                           # 1
print()                            # An empty line
print(1, 2, 3, 4, 5, 6, 7, 8, 11)  # 1 2 3 4 5 6 7 8 11
