
# num = int(float(input('How many do you need?')))
num = int(float('7.3'))
print(num)           # 7

print(float('7.3'))  # 7.3
print(str('7.3'))    # '7.3'
# print(int('7.3'))  # ValueError ...
