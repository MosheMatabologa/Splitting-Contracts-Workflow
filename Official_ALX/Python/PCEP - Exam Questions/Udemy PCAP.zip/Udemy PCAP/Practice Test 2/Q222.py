
class A:

    A = 7

    def __init__(self):
        self.a = 0


print(hasattr(A, 'A'))  # True
