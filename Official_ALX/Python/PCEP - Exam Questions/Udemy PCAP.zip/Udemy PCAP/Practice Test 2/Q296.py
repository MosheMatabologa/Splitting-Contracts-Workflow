
class A:
    pass


a = A()

b = B()  # NameError: name 'B' is not defined
