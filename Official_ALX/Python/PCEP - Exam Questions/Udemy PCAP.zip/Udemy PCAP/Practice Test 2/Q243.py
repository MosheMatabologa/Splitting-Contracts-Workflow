
s = 'python'
for i in range(len(s)):
    i = s[i].upper()
    # s[i] = s[i].upper()  # TypeError: ...
print(s, end="")       # python
