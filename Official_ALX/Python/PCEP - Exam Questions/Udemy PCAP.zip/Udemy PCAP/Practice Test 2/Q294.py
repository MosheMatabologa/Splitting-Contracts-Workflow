
class Aircraft:
    def start(self):
        return "default"

    def take_off(self):
        self.start()


class FixedWing(Aircraft):
    pass


class RotorCraft(Aircraft):
    def start(self):
        return "spin"


fleet = [FixedWing(), RotorCraft()]
for airship in fleet:
    print(airship.start(), end=" ")  # default spin
