
print(1 / 1)  # 1.0
