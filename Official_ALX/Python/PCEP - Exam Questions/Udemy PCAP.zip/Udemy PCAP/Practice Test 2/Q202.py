
data = 'abbabadaadbbaccabc'
print(data.count('ab', 1))  # 2
print(data.count('ab', 0))  # 3
