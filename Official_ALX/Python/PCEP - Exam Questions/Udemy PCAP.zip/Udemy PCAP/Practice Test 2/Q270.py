
print((lambda a, b, c, d, e: a+b+c+d+e)(1, 2, 3, 4, 5))  # 15
