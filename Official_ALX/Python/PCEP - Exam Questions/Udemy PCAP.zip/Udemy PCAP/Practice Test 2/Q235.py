
try:
    print('try')      # try
except:
    print('except')
finally:
    print('finally')  # finally
