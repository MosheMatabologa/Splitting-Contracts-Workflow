
try:
    # number = input('Please enter a number\n')
    number = 'one'
    zahl = int(number)
    print('Perfekt!')
except:
    print('Something went wrong.')
