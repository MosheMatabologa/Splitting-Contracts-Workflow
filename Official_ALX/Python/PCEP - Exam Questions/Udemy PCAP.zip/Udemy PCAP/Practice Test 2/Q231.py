
print('Peter' 'Wellert')  # PeterWellert

x = 'Hello' 'world'
print(x)  # Helloworld
