
i = 0
while i < i + 2:
    i += 1
    print('*')
    if i == 1000: break  # Safeguard
else:
    print('*')
