
x = 0
assert x == 0
print('Hello')  # Hello

x = 7
assert x == 0   # AssertionError
print('Hello')
