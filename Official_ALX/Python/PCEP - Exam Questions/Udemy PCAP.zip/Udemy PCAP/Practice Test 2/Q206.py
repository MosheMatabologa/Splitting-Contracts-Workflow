
print(1 // 2 * 3)    # 0

print((1 // 2) * 3)  # 0
print(0 * 3)         # 0
print(0)             # 0
