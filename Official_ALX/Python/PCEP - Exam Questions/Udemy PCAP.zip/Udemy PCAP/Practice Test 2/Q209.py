
i = 0
while i <= 5:
    print('1. i: ', i)  # 0 -> 1
    i += 1
    print('2. i: ', i)  # 1 -> 2
    if i % 2 == 0:  # False, True
        break
    print('*')  # *
