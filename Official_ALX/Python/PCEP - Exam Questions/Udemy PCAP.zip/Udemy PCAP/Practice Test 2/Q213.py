
def func(message, num=1):
    print(message * num)


func('Hello')       # Hello
func('Welcome', 3)  # WelcomeWelcomeWelcome
