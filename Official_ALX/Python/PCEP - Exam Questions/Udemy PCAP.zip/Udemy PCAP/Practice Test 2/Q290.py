
import random
print(random.choice("Hello"))  # e.g. H

import platform
print(platform.machine())      # e.g. x86_64
print(platform.system())       # e.g. Darwin
