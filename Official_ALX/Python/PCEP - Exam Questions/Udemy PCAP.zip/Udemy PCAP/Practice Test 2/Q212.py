
# Try it yourself

def func(para1, para2):  # Only this line is the function header
    return para1 + para2
