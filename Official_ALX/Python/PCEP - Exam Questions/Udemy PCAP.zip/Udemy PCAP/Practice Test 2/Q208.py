
x = True
y = False
x = x or y   # True or False -> True
y = x and y  # True and False -> False
x = x or y   # True or False -> True
print(x, y)  # True False
