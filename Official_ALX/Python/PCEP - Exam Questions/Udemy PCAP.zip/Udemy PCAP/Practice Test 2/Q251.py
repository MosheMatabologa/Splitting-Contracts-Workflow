
data = {'1': '0', '0': '1'}

# for d in data.values():
for d in data.vals():  # AttributeError: ...
    print(d, end=' ')    # 0 1
