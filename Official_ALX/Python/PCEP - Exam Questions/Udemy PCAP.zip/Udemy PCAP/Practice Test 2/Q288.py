
foo = (1, 2, 3)
foo.index(0)
# ValueError: tuple.index(x): x not in tuple
