
import calendar

print(calendar.weekheader(2))  # Mo Tu We Th Fr Sa Su
print(calendar.weekheader(3))  # Mon Tue Wed Thu Fri Sat Sun
print(calendar.week)  # <bound method TextCalendar ...
# print(calendar.weekheader())  # TypeError ....

print(calendar.weekheader(1))  # M T W T F S S
print(calendar.weekheader(4))  # Mon  Tue  Wed  Thu  Fri  Sat  Sun
