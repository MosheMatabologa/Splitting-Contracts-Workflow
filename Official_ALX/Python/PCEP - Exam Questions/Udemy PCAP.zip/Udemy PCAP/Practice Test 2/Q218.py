
for n in range(1, 6, 1):
    print(str(n) * 5)
"""
11111
22222
33333
44444
55555
"""

print('----------')

for n in range(1, 6, 1):
    print(n * 5)
"""
5
10
15
20
25
"""

print('----------')

for n in range(1, 6, 1):
    print(-1 * 5)
"""
-5
-5
-5
-5
-5
"""

print('----------')

for n in range(1, 6, 1):
    print(1 * 5)
"""
5
5
5
5
5
"""

print('----------')

for n in range(1, 6, 1):
    print(2 * 5)
"""
10
10
10
10
10
"""
