
print(ord('A'))  # 65
