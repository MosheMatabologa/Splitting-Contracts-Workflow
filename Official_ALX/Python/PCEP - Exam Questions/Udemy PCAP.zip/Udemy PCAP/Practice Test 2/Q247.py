
class A:
    def __init__(self, x=2, y=3):
        self.x = x
        self.y = y

    def __str__(self):
        return "A"

    def __eq__(self, other):
        return self.x * self.y == other.x * other.y


a = A(1, 2)
b = A(2, 1)
print(a == b)  # True
