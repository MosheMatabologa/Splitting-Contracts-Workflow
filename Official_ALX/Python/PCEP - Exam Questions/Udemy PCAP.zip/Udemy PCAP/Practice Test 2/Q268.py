
# IndexError:
# e1 = [1, 2][23]  # IndexError ...
print(IndexError.__subclasses__())  # []

# ImportError:
# import mat  # ModuleNotFoundError  ...
print(issubclass(ModuleNotFoundError, ImportError))  # True
print(ImportError.__subclasses__())
# [<class 'ModuleNotFoundError'>, <class 'zipimport.ZipImportError'>]

# ArithmeticError:
# e2 = 10 / 0  # ZeroDivisionError ...
print(issubclass(ZeroDivisionError, ArithmeticError))  # True
print(ArithmeticError.__subclasses__())
# [<class 'FloatingPointError'>, <class 'OverflowError'>, <class 'ZeroDivisionError'>]
