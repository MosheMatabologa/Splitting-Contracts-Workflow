
print(chr(ord('z') - 2))  # x
print(ord('z'))           # 122
print(chr(120))           # x
