
class Collection:
    stamps = 2

    def __init__(self, stuff):
        self.stuff = stuff

    def dispose(self):
        del self.stuff


binder = Collection(1)
binder.dispose()

print('stamps' in Collection.__dict__)                   # True
print(Collection.__dict__)  # {... 'stamps': 2, ...}
# stamps is a class variable
# and is include in the class's __dict__.

print(len(binder.__dict__) != len(Collection.__dict__))  # True
print(binder.__dict__)  # {}
print(len(Collection.__dict__))  # 7
# An object's __dict__ is not the same as the one of its class.

print('stuff' in binder.__dict__)                        # False
# dispose() removed the stuff variable from the object's __dict__.

print(len(binder.__dict__) > 0)                          # False
print(len(binder.__dict__))  # 0
# The object's __dict__ is empty.
