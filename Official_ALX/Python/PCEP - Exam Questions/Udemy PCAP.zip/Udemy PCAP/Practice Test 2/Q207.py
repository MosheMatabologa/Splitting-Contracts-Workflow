
x = 1
x = x == x
print(x)  # True
x = 1
x = x == x
x = (1 == 1)
x = True
