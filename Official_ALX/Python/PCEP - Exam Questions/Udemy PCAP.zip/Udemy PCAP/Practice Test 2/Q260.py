
from math import pi
print(pi)  # 3.141592653589793
