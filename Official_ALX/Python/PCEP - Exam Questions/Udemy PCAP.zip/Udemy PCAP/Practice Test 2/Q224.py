
import random
data = [10, 20, 30]
random.shuffle(data)
print(data)  # e.g. [20, 10, 30]

print(random.shuffle(data))  # None
