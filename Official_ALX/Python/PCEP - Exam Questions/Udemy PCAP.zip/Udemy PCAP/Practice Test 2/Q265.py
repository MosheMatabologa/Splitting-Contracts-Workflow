
text = 'Hello'
text += ' '
text += 'World'
print(text)                     # Hello World
print('Hello' + ' ' + 'World')  # Hello World
